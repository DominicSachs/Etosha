﻿namespace Etosha.Server.Common.Models
{
    public class ActionCallerContext
    {
    }
}
