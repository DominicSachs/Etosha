﻿namespace Etosha.Server.Entities
{
    public class Advice : BaseEntity
    {
        public string Code { get; set; }

        public string Description { get; set; }
    }
}
